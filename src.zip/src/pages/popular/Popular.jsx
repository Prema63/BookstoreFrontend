import React from 'react'
import AllBooks from '../../components/popular/AllBooks'

const Popular = () => {
  return (
    <div>
        <AllBooks/>
    </div>
  )
}

export default Popular