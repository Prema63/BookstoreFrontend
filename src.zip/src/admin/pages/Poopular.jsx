import React from 'react'

const Poopular = () => {
  return (
    <div>Poopular</div>
  )
}

export default Poopular